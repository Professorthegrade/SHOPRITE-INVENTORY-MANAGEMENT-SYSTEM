move the file here to the main folder.

move .editorconfig to the folder before this execution
